#!/usr/bin/env node

/**
 * 🛡️ SAFETY SMOKE TEST - End-to-End Safety System Verification
 * 
 * This script verifies the entire safety system:
 * 1. Guardian status endpoint
 * 2. Guardian emergency backup trigger
 * 3. Backup metadata validation
 * 4. Artifact presence and size thresholds
 * 5. Husky hooks and CI readiness
 * 
 * Usage: node scripts/safety-smoke.cjs [--base <url>]
 * Default base URL: http://localhost:3000
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

// Promisify fs functions
const readFile = promisify(fs.readFile);
const stat = promisify(fs.stat);

// Configuration
const CONFIG = {
  DEFAULT_BASE_URL: 'http://localhost:3000',
  TIMEOUT: 30000, // 30 seconds
  MIN_BUNDLE_SIZE: 100 * 1024, // 100KB minimum for repo.bundle (adjusted for smaller repos)
  MIN_ZIP_SIZE: 100 * 1024, // 100KB minimum for project.zip (adjusted for smaller projects)
  ENDPOINTS: {
    STATUS: '/api/guardian/status',
    EMERGENCY: '/api/guardian/emergency'
  }
};

// Utility functions
const utils = {
  log: (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    const prefix = {
      info: 'ℹ️',
      success: '✅',
      warning: '⚠️',
      error: '❌',
      progress: '🔄'
    }[type] || 'ℹ️';
    
    console.log(`${prefix} [${timestamp}] ${message}`);
  },
  
  formatBytes: (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  },
  
  parseArgs: () => {
    const args = process.argv.slice(2);
    let baseUrl = CONFIG.DEFAULT_BASE_URL;
    
    // Look for --base argument (both --base=url and --base url formats)
    for (let i = 0; i < args.length; i++) {
      if (args[i] === '--base' && i + 1 < args.length) {
        baseUrl = args[i + 1];
        break;
      } else if (args[i].startsWith('--base=')) {
        baseUrl = args[i].split('=')[1];
        break;
      }
    }
    
    return { baseUrl };
  }
};

// HTTP request helper
async function makeRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const { spawn } = require('child_process');
    
    // Use curl for HTTP requests (cross-platform)
    const args = [
      '-s', // Silent mode
      '-w', '%{http_code}', // Return HTTP status code
      '-o', '/dev/null', // Don't output response body
      '--max-time', '10', // 10 second timeout
      '--connect-timeout', '5' // 5 second connect timeout
    ];
    
    if (options.method === 'POST') {
      args.push('-X', 'POST');
      if (options.body) {
        args.push('-H', 'Content-Type: application/json');
        args.push('-d', options.body);
      }
    }
    
    args.push(url);
    
    const child = spawn('curl', args, { stdio: ['pipe', 'pipe', 'pipe'] });
    
    let stdout = '';
    let stderr = '';
    
    child.stdout?.on('data', (data) => {
      stdout += data.toString();
    });
    
    child.stderr?.on('data', (data) => {
      stderr += data.toString();
    });
    
    child.on('close', (code) => {
      if (code === 0) {
        resolve({ statusCode: parseInt(stdout), success: true });
      } else {
        reject(new Error(`curl failed: ${stderr}`));
      }
    });
    
    child.on('error', (error) => {
      reject(error);
    });
  });
}

// Test functions
async function testGuardianStatus(baseUrl) {
  utils.log('🔄 Testing Guardian status endpoint...', 'progress');
  
  try {
    const result = await makeRequest(`${baseUrl}${CONFIG.ENDPOINTS.STATUS}`);
    
    if (result.statusCode === 200) {
      utils.log('✅ Guardian status endpoint responding (200)', 'success');
      return true;
    } else {
      utils.log(`❌ Guardian status endpoint returned ${result.statusCode}`, 'error');
      return false;
    }
  } catch (error) {
    utils.log(`❌ Guardian status endpoint failed: ${error.message}`, 'error');
    return false;
  }
}

async function testGuardianEmergency(baseUrl) {
  utils.log('🔄 Testing Guardian emergency backup...', 'progress');
  
  try {
    const body = JSON.stringify({ reason: 'safety-smoke-test' });
    const result = await makeRequest(`${baseUrl}${CONFIG.ENDPOINTS.EMERGENCY}`, {
      method: 'POST',
      body
    });
    
    if (result.statusCode === 200) {
      utils.log('✅ Guardian emergency backup triggered successfully (200)', 'success');
      return true;
    } else {
      utils.log(`❌ Guardian emergency backup returned ${result.statusCode}`, 'error');
      return false;
    }
  } catch (error) {
    utils.log(`❌ Guardian emergency backup failed: ${error.message}`, 'error');
    return false;
  }
}

async function validateBackupMetadata() {
  utils.log('🔄 Validating backup metadata...', 'progress');
  
  try {
    const statusPath = path.join(process.cwd(), '.backups/meta/last.json');
    const statusData = await readFile(statusPath, 'utf-8');
    const status = JSON.parse(statusData);
    
    // Check required fields
    if (!status.hasOwnProperty('ok') || !status.hasOwnProperty('artifacts')) {
      utils.log('❌ Backup metadata missing required fields', 'error');
      return false;
    }
    
    // Check if backup was successful
    if (!status.ok) {
      utils.log('⚠️ Last backup was not successful', 'warning');
      // Continue with artifact validation
    }
    
    utils.log('✅ Backup metadata structure valid', 'success');
    return true;
  } catch (error) {
    utils.log(`❌ Backup metadata validation failed: ${error.message}`, 'error');
    return false;
  }
}

async function validateBackupArtifacts() {
  utils.log('🔄 Validating backup artifacts...', 'progress');
  
  try {
    const statusPath = path.join(process.cwd(), '.backups/meta/last.json');
    const statusData = await readFile(statusPath, 'utf-8');
    const status = JSON.parse(statusData);
    
    let allValid = true;
    let bundleFound = false;
    let zipFound = false;
    
    for (const artifact of status.artifacts) {
      if (artifact.type === 'git' && artifact.path) {
        try {
          const stats = await stat(artifact.path);
          if (stats.size >= CONFIG.MIN_BUNDLE_SIZE) {
            utils.log(`✅ Git bundle: ${utils.formatBytes(stats.size)}`, 'success');
            bundleFound = true;
          } else {
            utils.log(`❌ Git bundle too small: ${utils.formatBytes(stats.size)}`, 'error');
            allValid = false;
          }
        } catch (error) {
          utils.log(`❌ Git bundle not accessible: ${error.message}`, 'error');
          allValid = false;
        }
      }
      
      if (artifact.type === 'project' && artifact.path) {
        try {
          const stats = await stat(artifact.path);
          if (stats.size >= CONFIG.MIN_ZIP_SIZE) {
            utils.log(`✅ Project zip: ${utils.formatBytes(stats.size)}`, 'success');
            zipFound = true;
          } else {
            utils.log(`❌ Project zip too small: ${utils.formatBytes(stats.size)}`, 'error');
            allValid = false;
          }
        } catch (error) {
          utils.log(`❌ Project zip not accessible: ${error.message}`, 'error');
          allValid = false;
        }
      }
    }
    
    if (!bundleFound) {
      utils.log('❌ Git bundle artifact not found', 'error');
      allValid = false;
    }
    
    if (!zipFound) {
      utils.log('⚠️ Project zip artifact not found (may be optional)', 'warning');
    }
    
    return allValid;
  } catch (error) {
    utils.log(`❌ Artifact validation failed: ${error.message}`, 'error');
    return false;
  }
}

async function testHuskyHooks() {
  utils.log('🔄 Testing Husky hooks...', 'progress');
  
  try {
    const huskyDir = path.join(process.cwd(), '.husky');
    const preCommitPath = path.join(huskyDir, 'pre-commit');
    const prePushPath = path.join(huskyDir, 'pre-push');
    
    const preCommitExists = fs.existsSync(preCommitPath);
    const prePushExists = fs.existsSync(prePushPath);
    
    if (preCommitExists && prePushExists) {
      utils.log('✅ Husky hooks configured (pre-commit, pre-push)', 'success');
      return true;
    } else {
      utils.log('❌ Husky hooks missing', 'error');
      return false;
    }
  } catch (error) {
    utils.log(`❌ Husky hooks test failed: ${error.message}`, 'error');
    return false;
  }
}

async function testCIConfig() {
  utils.log('🔄 Testing CI configuration...', 'progress');
  
  try {
    const ciPath = path.join(process.cwd(), '.github/workflows/ci.yml');
    const packageJsonPath = path.join(process.cwd(), 'package.json');
    
    const ciExists = fs.existsSync(ciPath);
    const packageJson = JSON.parse(await readFile(packageJsonPath, 'utf-8'));
    
    if (ciExists && packageJson.scripts.ci) {
      utils.log('✅ CI workflow and npm ci script configured', 'success');
      return true;
    } else {
      utils.log('❌ CI configuration missing', 'error');
      return false;
    }
  } catch (error) {
    utils.log(`❌ CI config test failed: ${error.message}`, 'error');
    return false;
  }
}

// Main execution
async function main() {
  const { baseUrl } = utils.parseArgs();
  
  utils.log('🚀 Starting Safety Smoke Test...', 'info');
  utils.log(`🌐 Base URL: ${baseUrl}`, 'info');
  utils.log(`📁 Working directory: ${process.cwd()}`, 'info');
  
  const results = {
    guardianStatus: false,
    guardianEmergency: false,
    backupMetadata: false,
    backupArtifacts: false,
    huskyHooks: false,
    ciConfig: false
  };
  
  try {
    // Test 1: Guardian Status
    results.guardianStatus = await testGuardianStatus(baseUrl);
    
    // Test 2: Guardian Emergency
    results.guardianEmergency = await testGuardianEmergency(baseUrl);
    
    // Wait a moment for backup to complete
    if (results.guardianEmergency) {
      utils.log('⏳ Waiting for backup to complete...', 'progress');
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
    
    // Test 3: Backup Metadata
    results.backupMetadata = await validateBackupMetadata();
    
    // Test 4: Backup Artifacts
    results.backupArtifacts = await validateBackupArtifacts();
    
    // Test 5: Husky Hooks
    results.huskyHooks = await testHuskyHooks();
    
    // Test 6: CI Configuration
    results.ciConfig = await testCIConfig();
    
  } catch (error) {
    utils.log(`💥 Fatal error during testing: ${error.message}`, 'error');
    process.exit(1);
  }
  
  // Summary
  utils.log('\n📊 SAFETY SMOKE TEST RESULTS:', 'info');
  utils.log('─'.repeat(50), 'info');
  
  const testNames = {
    guardianStatus: 'Guardian Status Endpoint',
    guardianEmergency: 'Guardian Emergency Backup',
    backupMetadata: 'Backup Metadata Validation',
    backupArtifacts: 'Backup Artifacts Validation',
    huskyHooks: 'Husky Git Hooks',
    ciConfig: 'CI Configuration'
  };
  
  let passedTests = 0;
  let totalTests = Object.keys(results).length;
  
  for (const [key, result] of Object.entries(results)) {
    const status = result ? '✅ PASS' : '❌ FAIL';
    utils.log(`${status} ${testNames[key]}`, result ? 'success' : 'error');
    if (result) passedTests++;
  }
  
  utils.log('─'.repeat(50), 'info');
  utils.log(`📈 Overall: ${passedTests}/${totalTests} tests passed`, passedTests === totalTests ? 'success' : 'warning');
  
  if (passedTests === totalTests) {
    utils.log('🎉 All safety checks passed! System is secure.', 'success');
    process.exit(0);
  } else {
    utils.log('⚠️ Some safety checks failed. Review the results above.', 'warning');
    process.exit(1);
  }
}

// Handle process signals gracefully
process.on('SIGINT', () => {
  utils.log('🛑 Safety smoke test interrupted by user', 'warning');
  process.exit(130);
});

process.on('SIGTERM', () => {
  utils.log('🛑 Safety smoke test terminated', 'warning');
  process.exit(143);
});

// Run if called directly
if (require.main === module) {
  main().catch((error) => {
    utils.log(`💥 Unhandled error: ${error.message}`, 'error');
    process.exit(1);
  });
}

module.exports = { main, testGuardianStatus, testGuardianEmergency, validateBackupMetadata, validateBackupArtifacts, testHuskyHooks, testCIConfig };
