// Compatibility layer for deprecated exports
// This file contains deprecated re-exports during migrations

export * from './data';
export * from './lib';
export * from './ui';
