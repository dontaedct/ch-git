declare module "@/scripts/guardian.js" {
  const Guardian: any;
  export default Guardian;
}
