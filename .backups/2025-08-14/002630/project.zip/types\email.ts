export type SessionLite = { title: string; starts_at: string; location?: string };
