// Test simple import
const { zUUID } = require('./lib/validation');
console.log('zUUID:', zUUID);
