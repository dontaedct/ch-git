# 🛡️ Safety System Checklist

## Overview

This document provides a comprehensive, step-by-step manual verification process for the entire safety system. Use this checklist to manually verify that all safety mechanisms are functioning correctly.

## Prerequisites

- Node.js 18+ installed
- Git repository cloned and accessible
- Access to the application (running or deployed)
- curl command available (for API testing)

## 🚀 Quick Safety Smoke Test

For automated testing, use the safety smoke test script:

```bash
# Test against local development server
node scripts/safety-smoke.cjs

# Test against specific base URL
node scripts/safety-smoke.cjs --base=https://your-app.vercel.app

# Test against staging environment
node scripts/safety-smoke.cjs --base=https://staging.your-app.com
```

## 📋 Manual Verification Checklist

### 1. Guardian Backup System

#### 1.1 Status Endpoint Verification
- [ ] **Test Guardian Status API**
  ```bash
  curl -s http://localhost:3000/api/guardian/status
  ```
  - Expected: JSON response with `ok` field
  - Status: 200 OK
  - Contains backup metadata

- [ ] **Verify Response Structure**
  ```json
  {
    "ok": true|false,
    "artifacts": [...],
    "startedAt": "ISO_TIMESTAMP",
    "finishedAt": "ISO_TIMESTAMP"
  }
  ```

#### 1.2 Emergency Backup Verification
- [ ] **Trigger Emergency Backup**
  ```bash
  curl -X POST http://localhost:3000/api/guardian/emergency \
    -H "Content-Type: application/json" \
    -d '{"reason": "manual-safety-check"}'
  ```
  - Expected: Status 200 OK
  - Response includes backup artifacts
  - Backup process completes successfully

- [ ] **Verify Backup Execution**
  - Check console output for backup progress
  - Wait for completion (typically 1-5 minutes)
  - Verify no error messages

#### 1.3 Backup Artifacts Validation
- [ ] **Check Backup Directory Structure**
  ```bash
  ls -la .backups/
  ls -la .backups/meta/
  ls -la .backups/$(date +%Y-%m-%d)/
  ```

- [ ] **Verify Metadata File**
  ```bash
  cat .backups/meta/last.json
  ```
  - Contains valid JSON
  - Has required fields: `ok`, `artifacts`, `startedAt`, `finishedAt`
  - Timestamps are recent and logical

- [ ] **Validate Git Bundle**
  ```bash
  # Find the latest git bundle
  find .backups -name "repo.bundle" -type f -exec ls -lh {} \;
  
  # Verify bundle size (should be > 1MB)
  find .backups -name "repo.bundle" -type f -exec wc -c {} \;
  ```

- [ ] **Validate Project Archive**
  ```bash
  # Find the latest project zip
  find .backups -name "project.zip" -type f -exec ls -lh {} \;
  
  # Verify archive size (should be > 1MB)
  find .backups -name "project.zip" -type f -exec wc -c {} \;
  ```

### 2. Git Hooks (Husky)

#### 2.1 Pre-commit Hook Verification
- [ ] **Check Hook Configuration**
  ```bash
  ls -la .husky/
  cat .husky/pre-commit
  ```

- [ ] **Verify Hook Content**
  - Contains `npm run doctor`
  - Contains `npm run lint`
  - Contains `npm run typecheck`
  - Contains `npm run policy:enforce`
  - Contains Guardian health check

- [ ] **Test Hook Execution**
  ```bash
  # Make a small change to trigger pre-commit
  echo "# test" >> README.md
  git add README.md
  git commit -m "test commit"
  ```
  - Verify all checks run
  - Verify Guardian health check passes
  - Revert test change: `git reset --hard HEAD~1`

#### 2.2 Pre-push Hook Verification
- [ ] **Check Hook Configuration**
  ```bash
  cat .husky/pre-push
  ```

- [ ] **Verify Hook Content**
  - Calls `scripts/prepush.cjs`
  - Hook is executable

- [ ] **Test Hook Execution**
  ```bash
  # This will run the full pre-push suite
  # Only test if you have a remote configured
  git push origin HEAD
  ```
  - Verify linting runs
  - Verify type checking runs
  - Verify build completes
  - All checks should pass

### 3. CI/CD Pipeline

#### 3.1 GitHub Actions Verification
- [ ] **Check Workflow Configuration**
  ```bash
  cat .github/workflows/ci.yml
  ```

- [ ] **Verify Workflow Triggers**
  - Triggers on push to main/develop
  - Triggers on pull requests
  - Runs on Ubuntu latest
  - Tests Node.js 18.x and 20.x

- [ ] **Verify Workflow Steps**
  - Dependency installation
  - Linting
  - Type checking
  - Testing
  - Building

#### 3.2 Local CI Verification
- [ ] **Run Full CI Suite Locally**
  ```bash
  npm run ci
  ```
  - Linting passes
  - Type checking passes
  - Tests pass
  - Build succeeds

- [ ] **Verify Individual Steps**
  ```bash
  npm run lint
  npm run typecheck
  npm test
  npm run build
  ```

### 4. Backup Restoration Testing

#### 4.1 Git Bundle Restoration
- [ ] **Test Git Bundle Restoration**
  ```bash
  # Create a test directory
  mkdir -p /tmp/guardian-test-restore
  cd /tmp/guardian-test-restore
  
  # Clone from bundle
  git clone --mirror /path/to/your/repo/.backups/YYYY-MM-DD/HHMMSS/repo.bundle test-repo
  cd test-repo
  
  # Verify repository structure
  ls -la
  git log --oneline -5
  ```

#### 4.2 Project Archive Restoration
- [ ] **Test Project Archive Restoration**
  ```bash
  # Extract project archive
  unzip /path/to/your/repo/.backups/YYYY-MM-DD/HHMMSS/project.zip -d /tmp/project-restore
  
  # Verify project structure
  ls -la /tmp/project-restore/
  
  # Check for key files
  ls -la /tmp/project-restore/package.json
  ls -la /tmp/project-restore/README.md
  ```

### 5. Security Validation

#### 5.1 Environment Variables
- [ ] **Check for Exposed Secrets**
  ```bash
  # Search for potential secrets in code
  grep -r "API_KEY\|SECRET\|PASSWORD\|TOKEN" . --exclude-dir=node_modules --exclude-dir=.git
  
  # Check .env files (should not be committed)
  ls -la .env*
  ```

- [ ] **Verify .gitignore**
  ```bash
  cat .gitignore
  ```
  - Contains `.env*`
  - Contains `.backups/`
  - Contains sensitive directories

#### 5.2 Access Control
- [ ] **Verify RLS Policies**
  - Check Supabase RLS is enabled
  - Verify `coach_id = auth.uid()` constraints
  - Confirm service role key is server-side only

### 6. Performance and Reliability

#### 6.1 Backup Performance
- [ ] **Measure Backup Time**
  ```bash
  time node scripts/guardian.js --once
  ```
  - Should complete within 10 minutes
  - No timeout errors

- [ ] **Check Resource Usage**
  - Monitor CPU and memory during backup
  - Verify no excessive resource consumption

#### 6.2 Error Handling
- [ ] **Test Error Scenarios**
  - Disconnect network during backup
  - Remove write permissions from backup directory
  - Verify graceful error handling

## 🚨 Failure Scenarios

### Common Issues and Solutions

#### Guardian Status Fails
- **Symptom**: 404 or 500 error on `/api/guardian/status`
- **Check**: Application is running and Guardian service is accessible
- **Solution**: Restart application, check Guardian service logs

#### Backup Creation Fails
- **Symptom**: Emergency endpoint returns 500 or backup artifacts missing
- **Check**: Guardian script permissions, disk space, zip/git availability
- **Solution**: Ensure Guardian script is executable, check disk space

#### Husky Hooks Not Running
- **Symptom**: Git commits/pushes bypass safety checks
- **Check**: `.husky` directory exists, hooks are executable
- **Solution**: Reinstall Husky: `npm run prepare`

#### CI Pipeline Fails
- **Symptom**: GitHub Actions failing on lint/type/test/build
- **Check**: Local `npm run ci` output
- **Solution**: Fix issues locally, ensure CI passes before pushing

## 📊 Success Criteria

A successful safety verification should demonstrate:

1. ✅ **Guardian System**: Status and emergency endpoints respond correctly
2. ✅ **Backup Creation**: Artifacts are generated with proper sizes
3. ✅ **Metadata Integrity**: Backup status files contain valid information
4. ✅ **Git Hooks**: Pre-commit and pre-push hooks execute all checks
5. ✅ **CI Pipeline**: All automated checks pass locally and remotely
6. ✅ **Restoration**: Backup artifacts can be restored to working state
7. ✅ **Security**: No secrets exposed, proper access controls
8. ✅ **Performance**: Operations complete within reasonable timeframes

## 🔄 Regular Maintenance

### Daily
- Monitor Guardian backup logs
- Check for failed backup attempts

### Weekly
- Run full safety smoke test
- Verify backup artifact integrity
- Test restoration procedures

### Monthly
- Review and update safety checklist
- Audit security configurations
- Performance benchmarking

### Quarterly
- Full disaster recovery drill
- Update backup strategies
- Review and update CI/CD pipelines

## 📞 Emergency Contacts

- **System Administrator**: [Contact Info]
- **DevOps Team**: [Contact Info]
- **Security Team**: [Contact Info]

## 📚 Additional Resources

- [Guardian System Documentation](./GUARDIAN_README.md)
- [AI Rules and Guidelines](./AI_RULES.md)
- [Universal Header Requirements](../UNIVERSAL_HEADER.md)
- [Coach Hub Architecture](./COACH_HUB.md)

---

**Last Updated**: $(date +%Y-%m-%d)
**Version**: 1.0
**Maintainer**: Development Team
