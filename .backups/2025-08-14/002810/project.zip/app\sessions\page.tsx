export const dynamic = "force-dynamic";
export default async function SessionsPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Sessions</h1>
      <p>Temporary placeholder. If you can read this, the route is healthy.</p>
    </main>
  );
}
