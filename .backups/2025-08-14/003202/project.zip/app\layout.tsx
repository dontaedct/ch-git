import '@app/globals.tailwind.css';

export const metadata = { title: "Coach Hub (dev)", description: "Dev shell" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "system-ui, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
