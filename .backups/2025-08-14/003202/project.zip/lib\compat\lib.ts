// @deprecated Use @lib/* imports instead
// This file provides backward compatibility during migrations

/** @deprecated Use @lib/types instead */
export * from '@lib/types';

/** @deprecated Use @lib/email instead */
export * from '@lib/email';

/** @deprecated Use @lib/utils instead */
export * from '@lib/utils';

/** @deprecated Use @lib/validation instead */
export * from '@lib/validation';

/** @deprecated Use @lib/auth instead */
export * from '@lib/auth';

/** @deprecated Use @lib/supabase instead */
export * from '@lib/supabase';
