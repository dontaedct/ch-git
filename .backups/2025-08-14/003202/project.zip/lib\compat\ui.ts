// @deprecated Use @ui/* imports instead
// This file provides backward compatibility during migrations

/** @deprecated Use @ui/button instead */
export * from '@ui/button';

/** @deprecated Use @ui/input instead */
export * from '@ui/input';

/** @deprecated Use @ui/form instead */
export * from '@ui/form';

/** @deprecated Use @ui/card instead */
export * from '@ui/card';

/** @deprecated Use @ui/dialog instead */
export * from '@ui/dialog';

/** @deprecated Use @ui/select instead */
export * from '@ui/select';

/** @deprecated Use @ui/textarea instead */
export * from '@ui/textarea';

/** @deprecated Use @ui/checkbox instead */
export * from '@ui/checkbox';

/** @deprecated Use @ui/radio-group instead */
export * from '@ui/radio-group';

/** @deprecated Use @ui/switch instead */
export * from '@ui/switch';

/** @deprecated Use @ui/tabs instead */
export * from '@ui/tabs';

/** @deprecated Use @ui/accordion instead */
export * from '@ui/accordion';

/** @deprecated Use @ui/alert instead */
export * from '@ui/alert';

/** @deprecated Use @ui/badge instead */
export * from '@ui/badge';

/** @deprecated Use @ui/calendar instead */
export * from '@ui/calendar';

/** @deprecated Use @ui/dropdown-menu instead */
export * from '@ui/dropdown-menu';

/** @deprecated Use @ui/navigation-menu instead */
export * from '@ui/navigation-menu';

/** @deprecated Use @ui/popover instead */
export * from '@ui/popover';

/** @deprecated Use @ui/progress instead */
export * from '@ui/progress';

/** @deprecated Use @ui/scroll-area instead */
export * from '@ui/scroll-area';

/** @deprecated Use @ui/skeleton instead */
export * from '@ui/skeleton';

/** @deprecated Use @ui/slider instead */
export * from '@ui/slider';

/** @deprecated Use @ui/table instead */
export * from '@ui/table';

/** @deprecated Use @ui/toast instead */
export * from '@ui/toast';

/** @deprecated Use @ui/tooltip instead */
export * from '@ui/tooltip';
