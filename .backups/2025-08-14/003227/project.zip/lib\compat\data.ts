// @deprecated Use @data/* imports instead
// This file provides backward compatibility during migrations

/** @deprecated Use @data/clients instead */
export * from '@data/clients';

/** @deprecated Use @data/sessions instead */
export * from '@data/sessions';
